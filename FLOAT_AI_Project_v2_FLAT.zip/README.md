# FLOAT AI v1.0 — starter project

Konfigurasi:
- Nama: FLOAT AI
- Tema: Dark
- Bahasa: Indonesia
- Mesin AI: Gemini
- Android: Kotlin, minSdk 26, targetSdk 35

## Yang sudah ada di starter ini
- Activity pembuka dan permintaan izin overlay
- Gelembung AI yang bisa digeser
- Panel chat mengambang pada posisi awal tetap
- Panel chat mengambang dengan tombol minimize, hide, dan close
- Notifikasi untuk memunculkan gelembung lagi
- Quick Settings Tile (tambahkan tile FLOAT AI secara manual dari panel edit)
- Klien HTTP yang mengarah ke backend
- Contoh backend Node.js untuk meneruskan chat ke Gemini

## Membuka proyek
1. Pasang Android Studio versi stabil.
2. Ekstrak ZIP.
3. Android Studio > Open > pilih folder `FLOAT_AI_Project`.
4. Tunggu Gradle Sync.
5. Jalankan ke perangkat Android.

## Mengaktifkan overlay
1. Buka FLOAT AI.
2. Tekan "Aktifkan FLOAT AI".
3. Pada pengaturan Android, izinkan "Tampil di atas aplikasi lain".
4. Kembali ke aplikasi.
5. Jika Android meminta izin notifikasi, izinkan agar kontrol pemanggilan kembali mudah digunakan.
6. Tambahkan tile FLOAT AI melalui edit Quick Settings jika ingin memakai pintasan panel.

## Mengaktifkan Gemini
Aplikasi Android TIDAK boleh menyimpan Gemini API key secara langsung.
1. Deploy folder `backend` ke server HTTPS milik sendiri.
2. Atur environment variable `GEMINI_API_KEY` di server.
3. Isi `BACKEND_URL` pada `GeminiClient.kt` dengan URL HTTPS server, misalnya `https://domain-kamu.example/chat`.
4. Build dan jalankan ulang aplikasi.

Backend contoh memakai REST `generateContent`. Periksa dokumentasi Gemini untuk model yang tersedia dan ketentuan penggunaan terbaru.

## Membuat APK
Di Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

APK debug biasanya tersedia di:
`app/build/outputs/apk/debug/app-debug.apk`

## Catatan penting
- Ini adalah starter source project, bukan APK yang sudah dikompilasi atau diuji di perangkat.
- Fitur overlay memerlukan persetujuan eksplisit pengguna.
- Android/MIUI dapat membatasi proses latar belakang; perilaku notifikasi dan tile bisa berbeda menurut versi sistem.
- Untuk distribusi publik, tinjau kebijakan Android tentang foreground service dan special-use service.
- Tambahkan autentikasi, rate limiting, batas penggunaan, dan perlindungan penyalahgunaan pada backend sebelum dipublikasikan.


## Build APK melalui GitHub Actions (tanpa memasang Android Studio)
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke repository.
3. Buka tab Actions dan jalankan workflow "Build FLOAT AI APK" (atau tunggu build otomatis setelah push).
4. Jika build sukses, unduh artifact `FLOAT-AI-debug-apk`.
5. Ekstrak artifact dan instal `app-debug.apk` di perangkat Android.

Catatan: workflow ini hanya membangun APK debug. Gemini tetap memerlukan backend HTTPS yang sudah dideploy dan URL backend yang benar di `GeminiClient.kt`. Source ini belum diverifikasi melalui kompilasi di lingkungan ini.

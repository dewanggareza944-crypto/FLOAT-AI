package id.floatai.app

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.os.Build

class FloatTileService : TileService() {
    override fun onClick() {
        super.onClick()
        val intent = Intent(this, FloatingService::class.java)
            .setAction(FloatingService.ACTION_SHOW)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        qsTile?.state = Tile.STATE_ACTIVE
        qsTile?.updateTile()
    }
}

package id.floatai.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class FloatingService : Service() {
    companion object {
        const val ACTION_SHOW = "id.floatai.app.SHOW"
        const val ACTION_HIDE = "id.floatai.app.HIDE"
        const val ACTION_STOP = "id.floatai.app.STOP"
        private const val CHANNEL_ID = "float_ai_running"
        private const val NOTIFICATION_ID = 1001
    }

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_HIDE -> hideAll()
            ACTION_STOP -> stopSelf()
            else -> showBubble()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun baseParams(width: Int, height: Int): WindowManager.LayoutParams =
        WindowManager.LayoutParams(
            width, height, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin overlay belum diberikan.", Toast.LENGTH_LONG).show()
            return
        }
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "✦"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(0xFF6557E8.toInt(), 100)
            elevation = 12f
            setOnClickListener { showPanel() }
            setOnTouchListener(dragTouch { showPanel() })
        }
        bubble = b
        bubbleParams = baseParams(58, 58)
        wm.addView(b, bubbleParams)
    }

    private fun showPanel() {
        removeBubble()
        if (panel != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 12)
            background = rounded(0xFF171B28.toInt(), 24)
            elevation = 18f
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val heading = TextView(this).apply {
            text = "✦  FLOAT AI"
            textSize = 17f
            setTextColor(Color.WHITE)
        }
        val minimize = smallButton("—") { showBubble() }
        val hide = smallButton("◌") { hideAll() }
        val close = smallButton("×") { stopSelf() }
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(minimize); header.addView(hide); header.addView(close)
        root.addView(header)

        val transcript = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
        addMessage(transcript, "FLOAT AI", "Halo! Aku siap membantu. Tanyakan sesuatu, ya.")
        val scroll = ScrollView(this).apply { addView(transcript) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val inputRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "Tulis pesan..."
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF9AA4B8.toInt())
            textSize = 14f
            maxLines = 3
            background = rounded(0xFF252B3B.toInt(), 18)
            setPadding(14, 8, 14, 8)
        }
        val send = Button(this).apply { text = "Kirim" }
        inputRow.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        inputRow.addView(send)
        root.addView(inputRow)

        send.setOnClickListener {
            val prompt = input.text.toString().trim()
            if (prompt.isNotEmpty()) {
                input.setText("")
                addMessage(transcript, "Kamu", prompt)
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                send.isEnabled = false
                send.text = "..."
                thread {
                    val answer = GeminiClient.ask(prompt)
                    Handler(Looper.getMainLooper()).post {
                        addMessage(transcript, "FLOAT AI", answer)
                        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                        send.isEnabled = true
                        send.text = "Kirim"
                    }
                }
            }
        }

        panel = root
        panelParams = baseParams( minOf(resources.displayMetrics.widthPixels - 32, 360), 500).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
            x = 16; y = 120
        }
        wm.addView(root, panelParams)
    }

    private fun addMessage(parent: LinearLayout, who: String, message: String) {
        val label = TextView(this).apply {
            text = who
            textSize = 11f
            setTextColor(0xFF9FA9C0.toInt())
            setPadding(2, 8, 2, 2)
        }
        val body = TextView(this).apply {
            text = message
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(12, 10, 12, 10)
            background = rounded(if (who == "Kamu") 0xFF3B4772.toInt() else 0xFF252B3B.toInt(), 14)
        }
        parent.addView(label)
        parent.addView(body)
    }

    private fun smallButton(textValue: String, action: () -> Unit) =
        Button(this).apply {
            text = textValue
            textSize = 13f
            minWidth = 36
            setPadding(2, 0, 2, 0)
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }

    private fun dragTouch(onClick: (() -> Unit)?): View.OnTouchListener {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        return View.OnTouchListener { view, event ->
            val params = if (view === bubble) bubbleParams else panelParams
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params?.x ?: 0; startY = params?.y ?: 0
                    touchX = event.rawX; touchY = event.rawY; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > 8) moved = true
                    params?.let {
                        it.x = startX + dx; it.y = startY + dy
                        try { wm.updateViewLayout(view, it) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun removeBubble() {
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null; bubbleParams = null
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelParams = null
    }

    private fun hideAll() { removePanel(); removeBubble() }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "FLOAT AI aktif", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val showIntent = Intent(this, ShowOverlayReceiver::class.java).setAction(ACTION_SHOW)
        val pending = PendingIntent.getBroadcast(this, 2, showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val openApp = PendingIntent.getActivity(this, 3, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("FLOAT AI sedang aktif")
            .setContentText("Ketuk Tampilkan untuk membuka gelembung AI.")
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_view, "Tampilkan", pending)
            .setOngoing(true).build()
    }

    override fun onDestroy() {
        hideAll()
        super.onDestroy()
    }
}

package id.floatai.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object GeminiClient {
    // Ganti dengan URL backend HTTPS milikmu setelah backend dipasang.
    // Jangan menaruh Gemini API key langsung di aplikasi Android.
    private const val BACKEND_URL = "https://YOUR_BACKEND_DOMAIN/chat"

    fun ask(prompt: String): String {
        if (BACKEND_URL.contains("YOUR_BACKEND_DOMAIN")) {
            return "Tampilan FLOAT AI sudah dibuat. Untuk mengaktifkan jawaban Gemini, pasang backend terlebih dahulu dan isi BACKEND_URL di GeminiClient.kt."
        }
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(BACKEND_URL).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 30000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            val payload = JSONObject().put("message", prompt).toString()
            connection.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)
            json.optString("reply", "Maaf, belum ada jawaban dari server.")
        } catch (e: Exception) {
            "Tidak bisa terhubung ke server. Periksa internet dan backend. (${e.javaClass.simpleName})"
        } finally {
            connection?.disconnect()
        }
    }
}

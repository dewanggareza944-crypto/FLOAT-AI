package id.floatai.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
            setBackgroundColor(0xFF10131C.toInt())
        }

        val title = TextView(this).apply {
            text = "FLOAT AI"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val desc = TextView(this).apply {
            text = "Asisten AI mengambang • Gemini • Bahasa Indonesia"
            textSize = 15f
            setTextColor(0xFFB9C2D6.toInt())
            setPadding(0, 16, 0, 28)
        }
        val start = Button(this).apply {
            text = "Aktifkan FLOAT AI"
            setOnClickListener { enableAndStart() }
        }
        val note = TextView(this).apply {
            text = "Berikan izin tampil di atas aplikasi lain. Saat disembunyikan, gunakan notifikasi atau pintasan Quick Settings untuk memunculkannya kembali."
            textSize = 13f
            setTextColor(0xFFB9C2D6.toInt())
            setPadding(0, 24, 0, 0)
        }

        layout.addView(title)
        layout.addView(desc)
        layout.addView(start)
        layout.addView(note)
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun enableAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
            Toast.makeText(this, "Aktifkan izin FLOAT AI, lalu kembali ke aplikasi.", Toast.LENGTH_LONG).show()
            return
        }
        val intent = Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_SHOW)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent)
        else startService(intent)
        Toast.makeText(this, "FLOAT AI diaktifkan", Toast.LENGTH_SHORT).show()
        finish()
    }
}

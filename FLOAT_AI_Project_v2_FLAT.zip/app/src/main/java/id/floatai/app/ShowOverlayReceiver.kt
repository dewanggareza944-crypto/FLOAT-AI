package id.floatai.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class ShowOverlayReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val serviceIntent = Intent(context, FloatingService::class.java)
            .setAction(FloatingService.ACTION_SHOW)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(serviceIntent)
        else context.startService(serviceIntent)
    }
}

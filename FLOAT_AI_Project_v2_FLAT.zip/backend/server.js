import express from "express";

const app = express();
app.use(express.json({ limit: "32kb" }));

const API_KEY = process.env.GEMINI_API_KEY;
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";

app.post("/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: "GEMINI_API_KEY belum disetel." });
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Pesan kosong." });
    if (message.length > 8000) return res.status(413).json({ error: "Pesan terlalu panjang." });

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: "Kamu adalah FLOAT AI, asisten yang ramah, jelas, dan menjawab dalam Bahasa Indonesia." }]
          },
          contents: [{ role: "user", parts: [{ text: message }] }]
        })
      }
    );

    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API error:", data);
      return res.status(502).json({ error: "Gemini API gagal memproses permintaan." });
    }
    const reply = data.candidates?.[0]?.content?.parts
      ?.map(part => part.text || "")
      .join("") || "Belum ada jawaban.";
    res.json({ reply });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Kesalahan server." });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`FLOAT AI backend berjalan di port ${port}`));
